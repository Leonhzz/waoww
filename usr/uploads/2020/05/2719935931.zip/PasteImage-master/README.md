# PasteImage
为 Typecho 自带编辑器增加粘贴图片上传功能  

Typecho 最新开发版已经 [直接支持粘贴上传功能](https://github.com/typecho/typecho/commit/0b1096c588a68ac83eac283862fedb459afb3327)，本插件仅供旧版本使用。

## 安装方法
1. Download ZIP 下载本插件最新版本
2. 解压，把 `PasteImage-master` 目录重命名为 `PasteImage` 上传至博客的 `/usr/plugins` 目录下
3. 在插件页面启用本插件
